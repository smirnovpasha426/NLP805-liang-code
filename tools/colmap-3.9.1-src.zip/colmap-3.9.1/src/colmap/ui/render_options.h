// Copyright (c) 2023, ETH Zurich and UNC Chapel Hill.
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//
//     * Neither the name of ETH Zurich and UNC Chapel Hill nor the names of
//       its contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.

#pragma once

#include "colmap/util/logging.h"

#include <iostream>

namespace colmap {

struct RenderOptions {
  enum ProjectionType {
    PERSPECTIVE,
    ORTHOGRAPHIC,
  };

  // Minimum track length for a point to be rendered.
  int min_track_len = 3;

  // Maximum error for a point to be rendered.
  double max_error = 2;

  // The rate of registered images at which to refresh.
  int refresh_rate = 1;

  // Whether to automatically adjust the refresh rate. The bigger the
  // reconstruction gets, the less frequently the scene is rendered.
  bool adapt_refresh_rate = true;

  // Whether to visualize image connections.
  bool image_connections = false;

  // The projection type of the renderer.
  int projection_type = ProjectionType::PERSPECTIVE;

  inline bool Check() const {
    CHECK_OPTION_GE(min_track_len, 0);
    CHECK_OPTION_GE(max_error, 0);
    CHECK_OPTION_GT(refresh_rate, 0);
    CHECK_OPTION(projection_type == ProjectionType::PERSPECTIVE ||
                 projection_type == ProjectionType::ORTHOGRAPHIC);
    return true;
  }
};

}  // namespace colmap
